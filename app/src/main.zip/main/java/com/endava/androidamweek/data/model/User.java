package com.endava.androidamweek.data.model;

import java.util.ArrayList;

public class User {
    private String email;
    private String name;
    private ArrayList<SpeakerTrainings> training;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<SpeakerTrainings> getTraining() {
        return training;
    }

    public void setTraining(ArrayList<SpeakerTrainings> training) {
        this.training = training;
    }
}
