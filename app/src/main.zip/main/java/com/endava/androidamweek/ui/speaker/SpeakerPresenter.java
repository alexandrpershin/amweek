package com.endava.androidamweek.ui.speaker;

import com.endava.androidamweek.data.callbacks.SpeakerCallback;
import com.endava.androidamweek.data.model.Database;

class SpeakerPresenter {

    void loadSpeakers(SpeakerCallback speakerCallback){

        Database database = new Database();
        database.getSpeakersFromFirebase(speakerCallback);
    }
}
