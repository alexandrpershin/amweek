package com.endava.androidamweek.ui.training;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.endava.androidamweek.R;
import com.endava.androidamweek.data.model.Training;
import com.endava.androidamweek.ui.speaker.SpeakerClickListener;
import com.ramotion.foldingcell.FoldingCell;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

class TrainingsAdapter extends RecyclerView.Adapter<TrainingsAdapter.ViewHolder> {

    private List<Training> trainingList;
    private SpeakerClickListener speakerClickListener;

    void updateList(List<Training> trainings) {
        trainingList = trainings;
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.foldingCell)
        FoldingCell foldingCell;

        @BindView(R.id.foldTrainingTitle)
        TextView foldTrainingTitle;

        @BindView(R.id.foldShortDescription)
        TextView foldShortDescription;

        @BindView(R.id.foldTrainingTime)
        TextView foldTrainingTime;

        @BindView(R.id.foldTrainingSpeaker)
        TextView foldTrainingSpeaker;

        @BindView(R.id.unfoldTrainingTitle)
        TextView unfoldTrainingTitle;

        @BindView(R.id.unfoldDate)
        TextView unfoldDate;

        @BindView(R.id.unfoldTrainingLocation)
        TextView unfoldTrainingLocation;

        @BindView(R.id.unfoldTrainingTime)
        TextView unfoldTrainingTime;

        @BindView(R.id.unfoldTrainingDescription)
        TextView unfoldTrainingDescription;

        @BindView(R.id.unfoldSpeakerName)
        TextView unfoldSpeakerName;

        @BindView(R.id.speakerLayout)
        LinearLayout speakerLayout;

        ViewHolder(View v) {
            super(v);
            ButterKnife.bind(this, v);

            foldingCell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    foldingCell.toggle(false);
                }
            });

            speakerLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    speakerClickListener.onSpeakerClick(trainingList.get(getAdapterPosition()).getName());
                    Toast.makeText(view.getContext(), "NAME: " + trainingList.get(getAdapterPosition()).getName(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    TrainingsAdapter() {
        this.trainingList = new ArrayList<>();
    }

    @Override
    public TrainingsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_training, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Training item = trainingList.get(position);
        bindFoldView(holder, item);
        bindUnfoldView(holder, item);
    }

    private void bindFoldView(ViewHolder holder, Training item) {
        holder.foldTrainingTitle.setText(item.getName());
        holder.foldShortDescription.setText(item.getShortinfo());
        holder.foldTrainingTime.setText(item.getTime());
//        holder.foldTrainingSpeaker.setText(item.get());
    }

    private void bindUnfoldView(ViewHolder holder, Training item) {

        holder.unfoldTrainingTitle.setText(item.getName());
        holder.unfoldDate.setText(item.getDate());
        holder.unfoldTrainingLocation.setText(item.getLocation());
        holder.unfoldTrainingTime.setText(item.getTime());
        holder.unfoldTrainingDescription.setText(item.getLonginfo());
//        holder.unfoldSpeakerName.setText(item.getSpeaker());
    }

    @Override
    public int getItemCount() {
        return trainingList.size();
    }

    void setOnSpeakerClickListener(SpeakerClickListener speakerClickListener) {
        this.speakerClickListener = speakerClickListener;
    }

}