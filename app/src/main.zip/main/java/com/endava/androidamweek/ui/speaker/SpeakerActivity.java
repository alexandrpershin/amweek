package com.endava.androidamweek.ui.speaker;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.endava.androidamweek.R;
import com.endava.androidamweek.data.callbacks.SpeakerCallback;
import com.endava.androidamweek.data.model.Speaker;
import com.endava.androidamweek.data.model.Training;
import com.endava.androidamweek.ui.training.TrainingsFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SpeakerActivity extends AppCompatActivity implements SpeakerCallback {

    @BindView(R.id.speakerName)
    TextView speakerName;

    @BindView(R.id.speakerShortInfo)
    TextView speakerShortInfo;

    @BindView(R.id.speakerDescription)
    TextView speakerDescription;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.speakerTrainings)
    RecyclerView speakerTrainings;

    SpeakerTrainingsAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.speaker_profile);

        ButterKnife.bind(this);

        toolbar.setTitle("Speaker Profile");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        SpeakerPresenter speakerPresenter = new SpeakerPresenter();
        speakerPresenter.loadSpeakers(this);

        String trainingName = getIntent().getStringExtra(TrainingsFragment.TRAINING_NAME);

        speakerTrainings.setLayoutManager(new LinearLayoutManager(this));
        speakerTrainings.setItemAnimator(new DefaultItemAnimator());

        adapter = new SpeakerTrainingsAdapter();
        speakerTrainings.setAdapter(adapter);

    }

    @Override
    public void onSuccessResponse(List<Speaker> speakers) {
        System.out.println(Arrays.toString(speakers.toArray()));
        speakerName.setText(speakers.get(0).getName());
        speakerShortInfo.setText(speakers.get(0).getShortinfo());
        speakerDescription.setText(speakers.get(0).getLonginfo());

        List<Training> trainingList = new ArrayList<>();
        Training training = new Training();
        training.setDate("12/34/5675");
        training.setTime("12:24:46");
        training.setName("Edf kjdkj sdr");
        training.setShortinfo("Eg lkd lkg yuhdlf dk jkgkd kslsod");

        trainingList.add(training);
        trainingList.add(training);
        trainingList.add(training);

        adapter.updateList(trainingList);
    }

    @Override
    public void onErrorResponse(String errorMessage) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(menuItem);
    }
}
