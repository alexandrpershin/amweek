package com.endava.androidamweek.data.callbacks;

import com.endava.androidamweek.data.model.Training;

import java.util.List;

public interface TrainingCallback {

    void onSuccessResponse(List<Training> trainings);
    void onErrorResponse(String errorMessage);
}
