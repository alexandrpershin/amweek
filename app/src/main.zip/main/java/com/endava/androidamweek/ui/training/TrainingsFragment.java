package com.endava.androidamweek.ui.training;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.endava.androidamweek.R;
import com.endava.androidamweek.data.callbacks.TrainingCallback;
import com.endava.androidamweek.data.model.Training;
import com.endava.androidamweek.ui.speaker.SpeakerActivity;
import com.endava.androidamweek.ui.speaker.SpeakerClickListener;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TrainingsFragment extends Fragment implements TrainingCallback, SpeakerClickListener {

    public static final String TRAINING_NAME = "training name";

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    TrainingsAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_layout, container, false);

        ButterKnife.bind(this, view);

        TrainingsPresenter trainingsPresenter = new TrainingsPresenter();
        trainingsPresenter.loadTrainings(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        adapter = new TrainingsAdapter();

        adapter.setOnSpeakerClickListener(this);
        recyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onSuccessResponse(List<Training> trainings) {
        adapter.updateList(trainings);
    }

    @Override
    public void onErrorResponse(String errorMessage) {

    }

    @Override
    public void onSpeakerClick(String trainingName) {
        Intent intent = new Intent(getActivity(), SpeakerActivity.class);
        intent.putExtra(TRAINING_NAME, trainingName);
        startActivity(intent);
    }
}
