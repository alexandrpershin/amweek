package com.endava.androidamweek.ui.speaker;

public interface SpeakerClickListener {
    void onSpeakerClick(String trainingName);
}
