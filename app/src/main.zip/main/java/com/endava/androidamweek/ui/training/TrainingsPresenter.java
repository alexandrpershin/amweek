package com.endava.androidamweek.ui.training;

import com.endava.androidamweek.data.callbacks.TrainingCallback;
import com.endava.androidamweek.data.model.Database;

class TrainingsPresenter {

    void loadTrainings(TrainingCallback trainingCallback){
        Database database = new Database();
        database.getTrainingsFromFirebase(trainingCallback);
    }
}
